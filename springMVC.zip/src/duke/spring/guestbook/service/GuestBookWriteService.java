package duke.spring.guestbook.service;

public interface GuestBookWriteService {

	void write(Message message);

}
